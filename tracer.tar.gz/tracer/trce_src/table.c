#define EXTERN
#include "88.h"

char m[MEMBYTES];

REG r;
