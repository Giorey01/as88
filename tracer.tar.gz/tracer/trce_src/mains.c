#include "88.h"
#include "main_lib.h"

int main(int argc, char** argv) {
  stopvlag = traceflag = 0;
  return main_lib(argc, argv);
}
