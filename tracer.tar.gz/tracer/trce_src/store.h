#ifndef TRCE_SRC_STORE_H
#define TRCE_SRC_STORE_H

void wstore(int16_t x);
void xstore(char* x);
void rapwstore(int16_t w);

#endif /* TRCE_SRC_STORE_H */
