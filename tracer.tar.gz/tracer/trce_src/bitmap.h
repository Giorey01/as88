#ifndef TRCE_SRC_BITMAP_H
#define TRCE_SRC_BITMAP_H

void bitmapopen(int b, int h, int s);
void bitmapdump(int b, int h, char *buff);

#endif /* TRCE_SRC_BITMAP_H */
