#ifndef TRCE_SRC_COND_H
#define TRCE_SRC_COND_H

void cc(void);

#endif /* TRCE_SRC_COND_H */
