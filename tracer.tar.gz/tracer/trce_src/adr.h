#ifndef TRCE_SRC_ADR_H
#define TRCE_SRC_ADR_H

void wd(void);
void by(void);

#endif /* TRCE_SRC_ADR_H */
