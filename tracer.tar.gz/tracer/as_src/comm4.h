#ifndef AS_SRC_COMM4_H
#define AS_SRC_COMM4_H

void newmodule(char *s);
void stop(int dummy);

#endif /* AS_SRC_COMM4_H */
